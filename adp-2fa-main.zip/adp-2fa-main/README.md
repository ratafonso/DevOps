# Getting started with Github Enterprise cli authentication

⚠️ **macOS only**

This is a more comfortable commandline wrapper around the  `adp-2fa` [official client](https://github.developer.allianz.io/AgileDeliveryPlatform/2fa), with the goal to simplify its setup and usage.

## Installation

1. [Download](https://github.developer.allianz.io/KaiserXLabs/adp-2fa/archive/refs/heads/main.zip) the latest version of this repository.
2. Extract the `adp-2fa-main.zip` file into `~/Downloads`
3. Jump into the extrated folder with `cd ~/Downloads/adp-2fa-main`.
4. Run the provided install script 
```bash
./install.sh
```
3. Run `source $HOME/.zprofile` to activate the **$HOME/.zprofile**, or open a new terminal window

## Usage

⚠️ **In case you run into a macOS Gatekeeper issue and the command `github-cookie` will not be executed because the developer cannot ne verifiied, please run:**

```bash
sudo spctl --master-disable
```
*(admin rights needed to disable the macOS SecAssessment system)*

### Token Generation *(every 17h needed)*
Run the command `github-cookie <2fa-token>` and follow the dialog and enter your Github Enterprise OTP.

```bash
→ github-cookie                
OTP Code: ******
```

### Some useful `adp-2fa` commands

Retrieve information about the local offline token.
```bash
adp-2fa cookie info --offline_token ~/.github-cookie/offline.token
```

More about setting a specific cookie [here](https://github.developer.allianz.io/AgileDeliveryPlatform/2fa/blob/master/adp-2fa/README.md#get-a-cookie)