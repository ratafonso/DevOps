#!/bin/bash


if [[ $1 == "--help" ]]; then
  printf "usage: github-cookie [<otpCode>]\n\n"
  exit 0
fi

workingDirectory="${HOME}/.github-cookie"
user=$ADP_2FA_USER
otpCode=$1

if [[ -z "${user}" ]]; then
  printf "User email not set. \nPlease set the environment variable ADP_2FA_USER to your Allianz email address.\nAdd the following line to your .bash_profile file:\n
  export ADP_2FA_USER=john.doe@allianz.de
  \n"
  exit 1
fi

pass=$(security find-generic-password -ga ${user} -s github-enterprise -w 2> /dev/null)

if [[ -z "${pass}" ]]; then
  printf "Password for user %s cannot be found in your keychain.\n\n" "$user"
  exit 1
fi

if [[ -z "${otpCode}" ]]; then
  read  -n 6 -p "OTP Code: " otpCode
  printf "\n"
fi

if ! [[ $otpCode =~ ^[0-9]{6}$ ]]; then
  printf "You entered an invalid OTP code.\n\n"
  exit 1
fi

cd $workingDirectory

adp-2fa --username ${user} --password ${pass} --otp ${otpCode} cookie --global