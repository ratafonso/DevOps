#!/bin/bash

# hello statement
printf "\n\nThis CLI tool installs the adp-2fa tool\nfor the Allianz Github Enterprise.\n\n"

# get sudo rights for all the things
printf "Admin rights needed for the installtion process,\nyou have to enter your admin password afterwards.\n\nIs this ok? (y/N) "
read yesno < /dev/tty

if [ "x$yesno" = "xy" ];then
	sudo -v
else
	printf "Sorry, these script only runs with root rights. 🙈"
	exit
fi

printf "\n\nPlease enter your Github Enterprise credentials:\n\n"

# getting input from user about the credentials
read -p "Allianz Email Address: " user
read -s -p "GitHub Enterprise Password: " pass

# define requisite file paths and variables
arch=$(uname -m)
file="/usr/local/bin/github-cookie"
adpFile="/usr/local/bin/adp-2fa"
workingDirectory="${HOME}/.github-cookie"

if [ -f $file ]; then
  sudo rm ${file}
fi

if [ -f $adpFile ]; then
  sudo rm ${adpFile}
fi

if ! [ -d $workingDirectory ]; then
  mkdir $workingDirectory
  sudo chmod 777 $workingDirectory
fi

if [ "$arch" = "arm64" ]; then
    sudo cp ${PWD}/adp-2fa-${arch} ${adpFile}
else
    sudo cp ${PWD}/adp-2fa-${arch} ${adpFile}
fi

# copy files to corresponding paths
sudo cp ${PWD}/github-cookie.sh ${file}

# grant right to the files
sudo chmod 777 ${file} ${adpFile}

# checking whether a secret is already created in keychain
existing_pass=$(security find-generic-password -ga ${user} -s github-enterprise -w 2> /dev/null)

# if the secret already exists in keychain, delete it
if [ ! -z "${existing_pass}" ]; then
  printf "\n\nKeychain logging:\n\n----------------\n\n"
  security delete-generic-password -a ${user} -s github-enterprise
fi

# add secret to keychain
security add-generic-password -a ${user} -s github-enterprise -w ${pass}

printf "\n----------------\n\n"

# requisite environment variable definitions' strings
adp_user_line="export ADP_2FA_USER=\"${user}\""

# check each definition string whether it's already in the .zprofile, if not add it.
grep "$adp_user_line" $HOME/.zprofile|| echo $adp_user_line >> $HOME/.zprofile

printf "\nSuccessfully installed.\n\n\nRun github-cookie <2fa-token> to start the application.\n\n"

# Activate the profile
source $HOME/.zprofile